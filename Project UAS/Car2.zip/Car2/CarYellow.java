import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class carred here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CarYellow extends Enemy
{
    public void act() 
    {
        super.spawn();
    } 
    
}
