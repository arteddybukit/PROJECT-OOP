import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class CarBlue extends Enemy
{
    
    public void act() 
    {
        super.spawn();     
    }    
}
